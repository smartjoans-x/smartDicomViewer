<?php
/**
 * SmartViewer settings (this folder is closed to the web by .htaccess).
 */

declare(strict_types=1);

// Addresses where SmartViewer may run (host names only, no https://, no path).
// Added localhost and 127.0.0.1 for local testing.
const SV_ALLOWED_HOSTS = ['localhost', '127.0.0.1', '192.168.0.161'];

// How long the signed program link from index.php stays valid (seconds).
const SV_TOKEN_TTL = 1800;

/** Signing key: made once and kept in private/.sv_key */
function sv_secret(): string
{
    static $key = null;

    if ($key !== null) {
        return $key;
    }

    $file = __DIR__ . DIRECTORY_SEPARATOR . '.sv_key';

    if (!is_file($file)) {
        @file_put_contents($file, bin2hex(random_bytes(32)), LOCK_EX);
    }

    $key = trim((string)@file_get_contents($file));

    // Folder not writable: fall back to a key that is stable on this server
    if ($key === '') {
        $key = hash('sha256', __FILE__ . php_uname() . (string)filemtime(__FILE__));
    }

    return $key;
}

function sv_sign(int $exp): string
{
    $raw = hash_hmac('sha256', 'smartviewer|' . $exp, sv_secret(), true);

    return rtrim(strtr(base64_encode($raw), '+/', '-_'), '=');
}